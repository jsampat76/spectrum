<?php


namespace App;

use Illuminate\Database\Eloquent\Model;


class Parametervalue extends Model 
{

    protected $table = 'shc_pathtest_parametervalues';


}