<?php


namespace App;


use Illuminate\Database\Eloquent\Model;


class Shcuser extends Model
{
    
    protected $table = 'shc_users';
   
}