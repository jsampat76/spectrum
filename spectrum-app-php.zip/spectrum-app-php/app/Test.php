<?php


namespace App;

use Illuminate\Database\Eloquent\Model;


class Test extends Model 
{

    protected $table = 'shc_pathtest';

    public function Testidepartments()
    {
        return $this->hasOne('App\Department');
    }

}