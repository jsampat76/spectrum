<?php


namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Package;

class Reportold extends Model 
{
    
    protected $table = 'bkp_resultentry_reports';

     public function Testreportname()
    {
        return $this->hasOne('App\Test','id');
    }
 
    public function Testname()
    {
    return $this->belongsTo('App\Test','test_id','id')->select(array('id', 'reportname','param_id','format'));
    }
   
    public function Tests()
    {
        return $this->belongsTo('App\Test','test_id','id')->select(array('id', 'reportname'));
    }

    public function Packagenametest_unused()
    {
        return $this->hasManyThrough(
            'App\Reportold', 'App\Registrationold',
            'plan_id', 'reg_id', 'id'
        );
    } 

    public function Packagenametest()
    {
        /*
        return $this->hasManyThrough(
            'App\Package', 'App\Registrationold',
            'plan_id', 'id', 'reg_id'
        );
        */
        return $this->belongsTo('App\Package')->Packagenameold();
        //return 'App\Package'::Packagenameold();
    } 


  
}