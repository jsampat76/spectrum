<?php


namespace App;

use Illuminate\Database\Eloquent\Model;


class Registrationold extends Model 
{
    
    protected $table = 'bkp_appndisc_registrations';
   
}