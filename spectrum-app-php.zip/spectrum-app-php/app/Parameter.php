<?php


namespace App;

use Illuminate\Database\Eloquent\Model;


class Parameter extends Model 
{

    protected $table = 'shc_pathtest_parameters';

    public function Testidepartments()
    {
        return $this->hasMany('App\Parametervalues');
    }

}