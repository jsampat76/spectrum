<?php


namespace App;

use Illuminate\Database\Eloquent\Model;


class Department extends Model 
{

    protected $table = 'shc_pathtest_departments';


    public function Testidepartments()
    {
        return $this->belongsTo('App\Test');
    }
}