<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Package extends Model 
{

    protected $table = 'shc_pathtest_packages';
   
   public function Packagename()
    {
        return $this->hasManyThrough(
            'App\Report', 'App\Registration',
            'plan_id', 'reg_id', 'id'
        );
    } 

	

    public function Packagenameold()
    {
        return $this->hasManyThrough(
            'App\Reportold', 'App\Registrationold',
            'plan_id', 'id', 'reg_id'
        );
    } 
}