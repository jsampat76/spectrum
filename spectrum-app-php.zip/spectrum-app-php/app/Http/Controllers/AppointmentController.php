<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\User;
use App\Shcuser;
use App\Appointment;
use Auth;

class AppointmentController extends Controller
{
    
    public function registerAppointment(Request $request){
      if ($request->has('centerid') && $request->has('pat_id') && ($request->has('testIds') || $request->has('packageId'))) {

          $shcuser = Shcuser::where("id", "=", $request->input('pat_id'))->first();

         $result = array();
         

        //$user = new User;
        if($shcuser){
                    //$testids = implode(",",$request->input('testIds'));
                    $testids = str_replace(['[',']'], '', $request->input('testIds'));
                    $appmtn = new Appointment;
                    $appmtn->name = $shcuser->name;
                    $appmtn->patient_id = $shcuser->id;
                    $appmtn->gender = $shcuser->gender;
                    $appmtn->dob = $shcuser->dob;
                    $appmtn->contactno1 = $shcuser->mobile1;
                    $appmtn->contactno2 = $shcuser->mobile2;
                    $appmtn->cancelled = 2;
                    $appmtn->adminby = 228764;
                    $appmtn->online = 1;
                    $appmtn->added = 1;
                    $appmtn->plan = $request->input('packageId');
                    $appmtn->test_id = implode(",",$testids);
                    $appmtn->date = $request->input('date');
                    $appmtn->time = $request->input('time');
                    $appmtn->center_id = $request->input('centerid');

                   //return response()->json($appmtn);
                    
                    if($appmtn->save()){
                      $result['success'] = 1;
                      $result['message'] = "Appointment send successfully";
                      return response()->json($result);   
                    }
            } else {
                      $result['success'] = 0;
                      $result['message'] = "Problem in Appointment. Please do after some time!";
                      return response()->json($result);   
         }
        } else {
                      $result['success'] = 0;
                      $result['message'] = $testids;
                      return response()->json($result);  
        }
    }

  
    
}