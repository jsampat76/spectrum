<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use \Carbon\Carbon;
use App\User;
use App\Shcuser;
use App\Report;
use App\Reportold;
use App\Package;
use App\Parameter;
use App\Parametervalue;
use DB;
use Auth;

class ReportController extends Controller
{
    


   public function getreportresult(Request $request){
      if ($request->has('resultId')) {

        $result = array();  
        $resultparam = array();
        $resultval = array();
        $paramunit = array();
        $paramnormal = array();
        $paramreportname = array();
        $finalresult = array();
        $replace = array("[b]", "[/b]", "[u]", "[/u]");
        $graphs = array();

        $resultnew = report:: with('Testname')->select('id', 'test_id','pat_id','result','date','center_id')->where("id", "=", $request->input('resultId'))->where("action", "=", '1')->get();
        
        $resultold = reportold:: with('Testname')->select('id','test_id','pat_id','result','date','center_id')->where("id", "=", $request->input('resultId'))->where("action", "=", '1')->get();

        

        if(!$resultnew->isEmpty()){
         

         $resultoldarry = explode('|', $resultnew[0]->result);
         
          $result['testName'] = $resultnew[0]->testname->reportname;
          $result['success'] = 1;
          $Shcuser = Shcuser::select('dob','gender')->where('id', '=', $resultnew[0]->pat_id)->get();
          $result['Userinfo'] = $Shcuser;
          //////////////////bof get pdf graphs files//////////////
         // $directory = 'http://spectrumhealthcare.in/images/resultimages/'.$resultold[0]->center_id.'/'.$resultold[0]->id;
           $directory = '/home/spectrum/public_html/images/resultimages/'.$resultnew[0]->center_id.'/'.$resultnew[0]->id;
          if(is_dir($directory)){
            // create a handler for the directory
                $handler = opendir($directory);
                // open directory and walk through the filenames
                $f = 0;
                while ($file = readdir($handler)) {
                    // if file isn't this directory or its parent, add it to the results
                    if ($file != "." && $file != "..") {
                        $file_type = filetype($directory.'/'.$file);
                       // if ($file_type == 'pdf') {
                            //$graphs[$f] = '<a href = "http://spectrumhealthcare.in/images/resultimages/'.$resultold[0]->center_id.'/'.$resultold[0]->id.'/'.$file.'">'.$file.'</a>';
                        $graphs[$f] = $file;
                            $f++;
                       // }
                    }
                }
          }
          $result['graphs'] = $graphs;
          //////////////////eof get pdf graphs files//////////
          $paramarray = explode(',',$resultnew[0]->testname->param_id);

          $date = $resultnew[0]->date;
          $cDate = Carbon::parse($date);
          $birthdays =  $cDate->diffInDays();

          $parameters = DB::table('shc_pathtest_parameters')
            ->leftJoin('shc_pathtest_parametervalues', 'shc_pathtest_parameters.id', '=', 'shc_pathtest_parametervalues.parameter_id')
            ->select('shc_pathtest_parameters.id','shc_pathtest_parameters.parameters','shc_pathtest_parameters.reportname','shc_pathtest_parameters.unit','shc_pathtest_parameters.type','shc_pathtest_parameters.display','shc_pathtest_parametervalues.gender','shc_pathtest_parametervalues.low','shc_pathtest_parametervalues.high','shc_pathtest_parametervalues.start_day','shc_pathtest_parametervalues.end_day','shc_pathtest_parametervalues.normalrange')
            ->whereIn('shc_pathtest_parameters.id', $paramarray)
            //->where('shc_pathtest_parametervalues.gender', '=', $Shcuser[0]->gender)
            //->where('shc_pathtest_parametervalues.start_day', '<=', $birthdays)
            //->where('shc_pathtest_parametervalues.end_day', '>=', $birthdays)
            ->distinct()
            ->get();

          $i = 0;
          foreach($resultoldarry as $value){ //iterate trhrough result value
            $tempobject =  (object)[];
            $resultparamsval = explode('=', $value);
            $tempobject->result = $resultparamsval[1];
            $tempobject->result = str_replace($replace, '', $tempobject->result);

            if(empty($resultparamsval[1]) || $resultparamsval[1] == '   ') continue; //skip if there is no result value
            foreach($parameters as $parameter){
              
              if($parameter->parameters == $resultparamsval[0]){ //iteate through parameters having units and normalrang
                $tempobject->reportname = $parameter->reportname;
                $tempobject->type = $parameter->type;
              }
              
              if($parameter->parameters == $resultparamsval[0] && $parameter->gender == $Shcuser[0]->gender && $parameter->start_day <=  $birthdays && $parameter->end_day >= $birthdays){
                $tempobject->unit = $parameter->unit;
                $tempobject->high = $parameter->high;
                $tempobject->low = $parameter->low;
                $tempobject->normalrange = $parameter->normalrange;          
              }
            }
            $finalresult[$i] = $tempobject;
            $i++;
          }

         $result['format'] = $resultnew[0]->testname->format;
         $result['finalresult'] = $finalresult;
         

        }
        


        ///////////bof result from backup table////////////////////////////////////////////////////////////

        if(!$resultold->isEmpty()){

          $resultoldarry = explode('|', $resultold[0]->result);
         // $resultparamsval = explode('=', $resultoldarry);
          
          //$result['resultoldarray'] = $resultoldarry;
          $result['testName'] = $resultold[0]->testname->reportname;
          $result['success'] = 1;
          $Shcuser = Shcuser::select('dob','gender')->where('id', '=', $resultold[0]->pat_id)->get();
          $result['Userinfo'] = $Shcuser;
          //////////////////bof get pdf graphs files//////////////
         // $directory = 'http://spectrumhealthcare.in/images/resultimages/'.$resultold[0]->center_id.'/'.$resultold[0]->id;
           $directory = '/home/spectrum/public_html/images/resultimages/'.$resultold[0]->center_id.'/'.$resultold[0]->id;
          if(is_dir($directory)){
            // create a handler for the directory
                $handler = opendir($directory);
                // open directory and walk through the filenames
                $f = 0;
                while ($file = readdir($handler)) {
                    // if file isn't this directory or its parent, add it to the results
                    if ($file != "." && $file != "..") {
                        $file_type = filetype($directory.'/'.$file);
                       // if ($file_type == 'pdf') {
                            $graphs[$f] = $file;
                            $f++;
                       // }
                    }
                }
          }
          $result['graphs'] = $graphs;
          //////////////////eof get pdf graphs files//////////
          $paramarray = explode(',',$resultold[0]->testname->param_id);

          $date = $resultold[0]->date;
          $cDate = Carbon::parse($date);
          $birthdays =  $cDate->diffInDays();

          $parameters = DB::table('shc_pathtest_parameters')
            ->leftJoin('shc_pathtest_parametervalues', 'shc_pathtest_parameters.id', '=', 'shc_pathtest_parametervalues.parameter_id')
            ->select('shc_pathtest_parameters.id','shc_pathtest_parameters.parameters','shc_pathtest_parameters.reportname','shc_pathtest_parameters.unit','shc_pathtest_parameters.type','shc_pathtest_parameters.display','shc_pathtest_parametervalues.gender','shc_pathtest_parametervalues.low','shc_pathtest_parametervalues.high','shc_pathtest_parametervalues.start_day','shc_pathtest_parametervalues.end_day','shc_pathtest_parametervalues.normalrange')
            ->whereIn('shc_pathtest_parameters.id', $paramarray)
            //->where('shc_pathtest_parametervalues.gender', '=', $Shcuser[0]->gender)
            //->where('shc_pathtest_parametervalues.start_day', '<=', $birthdays)
            //->where('shc_pathtest_parametervalues.end_day', '>=', $birthdays)
            ->distinct()
            ->get();

          $i = 0;
          foreach($resultoldarry as $value){ //iterate trhrough result value
            $tempobject =  (object)[];
            $resultparamsval = explode('=', $value);
            $tempobject->result = $resultparamsval[1];
            $tempobject->result = str_replace($replace, '', $tempobject->result);

            if(empty($resultparamsval[1]) || $resultparamsval[1] == '   ') continue; //skip if there is no result value
            foreach($parameters as $parameter){
              
              if($parameter->parameters == $resultparamsval[0]){ //iteate through parameters having units and normalrang
                $tempobject->reportname = $parameter->reportname;
                $tempobject->type = $parameter->type;
              }
              
              if($parameter->parameters == $resultparamsval[0] && $parameter->gender == $Shcuser[0]->gender && $parameter->start_day <=  $birthdays && $parameter->end_day >= $birthdays){
                $tempobject->unit = $parameter->unit;
                $tempobject->high = $parameter->high;
                $tempobject->low = $parameter->low;
                $tempobject->normalrange = $parameter->normalrange;          
              }
            }
            $finalresult[$i] = $tempobject;
            $i++;
          }

         $result['format'] = $resultold[0]->testname->format;
         $result['finalresult'] = $finalresult;
         

        }
        $result['testingResultOLD'] = $resultold;
         $result['testingResultNew'] = $resultnew;
        return response()->json($result);
      
      } else {
        return "Bad Request";
      }
    }
}