<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Center;
use Auth;
use DB;

class CenterController extends Controller
{
    
  public function centerList(Request $request){
   // $centers = Center::where("active", "=", "1")->orderBy('centers','ASC')->get(['id','centers']);
    /*
    $centers = DB::table('shc_center_department')
            ->leftJoin('shc_pathtest_centers', 'shc_center_department.center_id', '=', 'shc_pathtest_centers.id')
            ->select('shc_pathtest_centers.id','shc_pathtest_centers.centers')
            ->where('shc_center_department.department_id', $departmentid)
            //->distinct()
            ->get(['shc_pathtest_centers.id','shc_pathtest_centers.centers']);
    */
            
    $centers = DB::table('shc_pathtest_centers')
                ->select('id','centers')
                ->where('active', '=', 1)
                ->get();

    return response()->json($centers);
  }
 
 public function appointmentTests(Request $request, $centerid, $departmentid){
 	$tests = DB::table('shc_pathtest_rates')
            ->leftJoin('shc_pathtest', 'shc_pathtest.id', '=', 'shc_pathtest_rates.test_id')
            ->select('shc_pathtest.id','shc_pathtest.reportname','shc_pathtest_rates.rate')
            ->where('shc_pathtest.department_id', $departmentid)
            ->where('shc_pathtest.mobileuse', 1)
            ->where('shc_pathtest_rates.center_id', $centerid)
            ->orderBy('shc_pathtest.reportname','asc')
            //->distinct()
            ->get(['shc_pathtest.id','shc_pathtest.reportname','shc_pathtest_rates.rate']);
    return response()->json($tests);

 }
    
}