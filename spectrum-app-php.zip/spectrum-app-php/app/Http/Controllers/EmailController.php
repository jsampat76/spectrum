<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Center;
use DB;
//use App\Mail\AppointmentCorporatemail;
//use App\Mail\MyTest;

//use Illuminate\Support\Facades\Mail;

class EmailController extends Controller
{
    public function sendEmailTests(Request $request){
     // $centerid = $request->input('centerId');
      $usertype = $request->input('usertype');
      $patid = $request->input('pat_id');
      $Tests = $request->input('Tests');
//$result['PatId'] = $request->input('pat_id');;
//return response()->json($result);
      /*
      $center_name = DB::table('shc_pathtest_centers')
                ->select('centers')
                ->where('id', '=', $centerid)
                ->first();
    */
      $userinfo = DB::table('shc_users')
                ->select('name','dob','mobile1','mobile2')
                ->where('id', '=', $patid)
                ->first();
                
      if($usertype == 1) {
        $usertype = "Individual";
      }
      if($usertype == 2) {
        $usertype = "Corporate";
      }
      
      

      $comment = "Name: ".$userinfo->name." <br>"; 
      $comment .= "Patient ID: ".$patid." <br>"; 
      $comment .= "Mobile 1: ".$userinfo->mobile1." <br>";
      $comment .= "User Type: ".$usertype."<br>";
      //$comment .= "Center: ".$center_name->centers."<br>";
      $comment .= "<br><strong>Tests Requested: </strong>"."<br>";
      if($Tests['Radiology'] != ""){
        $comment .= "<strong>Radiology Tests: </strong>"."<br>";
        $comment .= nl2br($Tests['Radiology'])."<br><br>";
      }
      if($Tests['Pathology'] != ""){
        $comment .= "<strong>Pathology Tests: </strong>"."<br>";
        $comment .= nl2br($Tests['Pathology'])."<br><br>";
      }
      if($Tests['Cardiology'] != ""){
        $comment .= "<strong>Cardiology Tests: </strong>"."<br>";
        $comment .= nl2br($Tests['Cardiology'])."<br><br>";
      }
      if($Tests['Others'] != ""){
        $comment .= "<strong>Other Tests: </strong>"."<br>";
        $comment .= nl2br($Tests['Others'])."<br><br>";
      }
      

      $headers = '';

      // this is the subject of the message
      $subject = "New Appointment Request";
      $headers .= "Content-type: text/html\r\n";
      $headers .= 'From: Spectrum Healthcare<appts@spectrumhealthcare.co.in>' . "\r\n";
      $headers .= 'BCC: jmayuri86@gmail.com' . "\r\n";

      $message  = "";
      $message .= "{$comment}";
     // $send = @mail($global_email, $subject, $message, $headers);

      if(@mail('appts@spectrumhealthcare.co.in', $subject, $message, $headers)){      
      $result['success'] = true;
      }else{
      $result['success'] = false;
      }
      
      return response()->json($result);
    }



    public function sendEmail(Request $request){

     // $centerid = $request->input('centerId');
      $usertype = $request->input('usertype');
      $patid = $request->input('pat_id');
      /*
      $center_name = DB::table('shc_pathtest_centers')
                ->select('centers')
                ->where('id', '=', $centerid)
                ->first();
      */
      $userinfo = DB::table('shc_users')
                ->select('name','dob','mobile1','mobile2')
                ->where('id', '=', $patid)
                ->first();
     
      if($usertype == 1) {
        $usertype = "Individual";
      }
      if($usertype == 2) {
        $usertype = "Corporate";
      }
      
      $plan = $request->input('Plan');

      $comment = "Name: ".$userinfo->name." <br>"; 
      $comment .= "Patient ID: ".$patid." <br>"; 
      $comment .= "Mobile 1: ".$userinfo->mobile1." <br>";
      $comment .= "User Type: ".$usertype."<br>";
      //$comment .= "Center: ".$center_name->centers."<br>";
      $comment .= "Plan: ".$plan."<br>";

      $headers = '';

      // this is the subject of the message
      $subject = "New Appointment Request";
      $headers .= "Content-type: text/html\r\n";
      $headers .= 'From: Spectrum Healthcare<appts@spectrumhealthcare.co.in>' . "\r\n";
       $headers .= 'BCC: jmayuri86@gmail.com' . "\r\n";

      $message  = "";
      $message .= "{$comment}";
     // $send = @mail($global_email, $subject, $message, $headers);

      if(@mail('appts@spectrumhealthcare.co.in', $subject, $message, $headers)){      
      $result['success'] = true;
      }else{
      $result['success'] = false;
      }
      
      return response()->json($result);

     }

  
    
}