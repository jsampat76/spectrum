<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\User;
use App\Report;
use App\Reportold;
use App\Package;
use App\Test;
use App\Testrate;
use App\Department;
use DB;

use Auth;

class TestController extends Controller
{
    
    public function gettestlist(Request $request){
      if ($request->has('regId') && $request->has('departmentId') ) {
        $departmentId = $request->input('departmentId');
        //$registrations = Registration:: where("patient_id", "=", $request->input('userId'))->first();
        $testlist = report:: with(['Testname' => function($query) use($request){
            $query->where('department_id', '=', $request->input('departmentId'));
        }])->select('id','test_id')->where("reg_id", "=", $request->input('regId'))->where("action", "=", '1')->get();
        
        $testlistold = reportold::with(['Testname' => function($query) use($request){
            $query->where('department_id', '=', $request->input('departmentId'));
        }])->select('id','test_id')->where("reg_id", "=", $request->input('regId'))->where("action", "=", '1')->get();
   
    //dd($testlistold);

        if (!$testlist->isEmpty() || !$testlistold->isEmpty()) {
           
           $testlist = $testlist->reject(function ($item) {      
              return $item->Testname == NULL;
            });

            $testlistold = $testlistold->reject(function ($item) {      
              return $item->Testname == NULL;
            });

          $result = array();
          $result['testlist'] = $testlist;
          $result['testlistold'] = $testlistold;
          $result['success'] = 1;
          return response()->json($result);

        } else {
          
          $result['success'] = false;

        }
      } else {
        return "Bad Request";
      }
    }

    public function gettestlistOLD(Request $request){
      if ($request->has('regId')) {
        //$registrations = Registration:: where("patient_id", "=", $request->input('userId'))->first();
        $testlist = report:: with('Testname')->select('id','test_id')->where("reg_id", "=", $request->input('regId'))->where("action", "=", '1')->orderBy('id','DESC')->get();
        
        $testlistold = reportold:: with('Testname')->select('id','test_id')->where("reg_id", "=", $request->input('regId'))->where("action", "=", '1')->orderBy('id','DESC')->get();


        if ($testlist || $testlistold) {
          
          $result = array();
          $result['testlist'] = $testlist;
          $result['testlistold'] = $testlistold;
          $result['success'] = 1;
          return response()->json($result);

        } else {
          
          $result['success'] = false;

        }
      } else {
        return "Bad Request";
      }
    }

    public function getTestswithdepartment(Request $request){
      $result = array();
      if ($request->has('regId')){

            $shcTests = DB::table('shc_resultentry_reports')
            ->leftJoin('shc_pathtest', 'shc_resultentry_reports.test_id', '=', 'shc_pathtest.id')
            ->leftJoin('shc_pathtest_departments', 'shc_pathtest.department_id', '=', 'shc_pathtest_departments.id')
            ->select('shc_resultentry_reports.id','shc_resultentry_reports.test_id','shc_pathtest.reportname','shc_pathtest.format','shc_pathtest.department_id','shc_pathtest_departments.departments')
            ->where('shc_resultentry_reports.reg_id','=', $request->input('regId'))
            ->where('shc_resultentry_reports.action', '=', 1)
            ->orderBy('shc_pathtest_departments.departments','asc')
            ->orderBy('shc_pathtest.reportname','asc')
            ->get();

        if($shcTests->isEmpty()){
          $shcTests = DB::table('bkp_resultentry_reports')
            ->leftJoin('shc_pathtest', 'bkp_resultentry_reports.test_id', '=', 'shc_pathtest.id')
            ->leftJoin('shc_pathtest_departments', 'shc_pathtest.department_id', '=', 'shc_pathtest_departments.id')
            ->select('bkp_resultentry_reports.id','bkp_resultentry_reports.test_id','shc_pathtest.reportname','shc_pathtest.department_id','shc_pathtest_departments.departments','shc_pathtest.format')
            ->where('bkp_resultentry_reports.reg_id','=', $request->input('regId'))
            ->where('bkp_resultentry_reports.action', '=', 1)
            ->orderBy('shc_pathtest_departments.departments','asc')
            ->orderBy('shc_pathtest.reportname','asc')
            ->get();
        }
        
        $finalresult = array();
        foreach($shcTests as $shcTest){
            for($i = 1; $i <= 22; $i++){
              if($shcTest->department_id == $i){
                $tempobject =  (object)[];
                $tempobject->id = $shcTest->id;
                $tempobject->test_id = $shcTest->test_id;
                $tempobject->reportname = $shcTest->reportname;
                $tempobject->department_id = $shcTest->department_id;
                $tempobject->departments = $shcTest->departments;
                $tempobject->format = $shcTest->format;
                $finalresult[$shcTest->departments][] = $tempobject;
              }
              
            }            
        }
        
          $result['shcTests'] = $shcTests;
          $result['finalresult'] = $finalresult;
          return response()->json($result);

      }else{
        return "Bad Request";
      }
    }

    public function getTestlistforAppinment(Request $request){
              $testlist = test::select('id','tests')->where('active', 1)->where('mobileuse', 1)->orderBy('tests','ASC')->get();
              $result = array();
              //$result['testlist'] = $testlist;
              return response()->json($testlist);
    }


    public function testsearch(Request $request){

        if ($request->has('centerId') && $request->has('testword')) {
          
          //$testlist = test::with('Testrate')->select('id','tests')->where([['tests', 'like', '%'.$request->input('testword').'%']])->get();

          $testlist = test::select('id','tests')->where([['tests', 'like', '%'.$request->input('testword').'%']])->orderBy('tests','ASC')->get();

          $result = array();
          //$result['testlist'] = $testlist;
          return response()->json($testlist);

        }else{
          return $result['success'] = false;
        }



    }

    
}