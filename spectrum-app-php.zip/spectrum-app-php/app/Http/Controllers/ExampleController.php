<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\User;
use Illuminate\Contracts\Auth\Factory as Auth;

class ExampleController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function getUser(Request $request){
       // $user = User::find($id)->where();
        /*
       $user = User::where('username', $request->input('username'))
                ->where('password',md5($request->input('password')))
                ->get();
                */
       //$user = User::where('password', md5($request->input('password')))->get();
       $user = User::where('username', $request->input('username'))->get();
            // Creating a token without scopes...
            //$token = $user->createToken('secret')->accessToken;

            // Creating a token with scopes...
            //$token = $user->createToken('secret', ['place-orders'])->accessToken;
        return $user;
    }

    public function CheckMySql(){

           $dbhost = 'localhost:3036';
           $dbuser = 'root';
           $dbpass = 'root';

           $myPDO = new PDO('mysql:host=localhost;dbname=spectrum_emr', 'root', 'root');
           /*
           $conn = mysql_connect($dbhost, $dbuser, $dbpass);
           
           if(! $conn ) {
              $res = 'Could not connect: ' . mysql_error();
           }
           
              $res = 'Connected successfully';

           mysql_close($conn);
           */
        return $myPDO;
    }

    //
}
