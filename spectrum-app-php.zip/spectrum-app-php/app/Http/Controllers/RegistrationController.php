<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\User;
use App\Registration;
use App\Registrationold;
use Auth;

class RegistrationController extends Controller
{
    private $salt;
    public function __construct()
    {
        $this->salt="userloginregister";
    }
    public function getregistrationlist(Request $request){
      if ($request->has('userId')) {
        //$registrations = Registration:: where("patient_id", "=", $request->input('userId'))->first();
        $registrations = Registration:: where("patient_id", "=", $request->input('userId'))->orderBy('date','DESC')->get(['id','date']);
        $registrationsold = Registrationold:: where("patient_id", "=", $request->input('userId'))->orderBy('date','DESC')->get(['id','date']);
                      //return $user;
        if ($registrations || $registrationsold) {
          
          $result = array();
          $result['registrations'] = $registrations;
          $result['registrationsold'] = $registrationsold;
          $result['success'] = 1;
          return response()->json($result);
        } else {
          
          $result['success'] = false;
        }
      } else {
        return "Bad Request";
      }
    }
}