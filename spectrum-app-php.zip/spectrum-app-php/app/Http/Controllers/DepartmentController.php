<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\User;
use App\Department;

use Auth;

class DepartmentController extends Controller
{
    
    public function getalldepartments(Request $request){
     
        //$registrations = Registration:: where("patient_id", "=", $request->input('userId'))->first();
        $departmentlist = department::where('mobileuse', 1)->get();

       if(!$departmentlist->isEmpty()){
          
          $result = array();
          $result['departmentlist'] = $departmentlist;
          $result['success'] = 1;
          return response()->json($result);

        } else {
          
          $result['success'] = false;

        }
      
    }

    
}