<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\User;
use App\Report;
use App\Reportold;
use App\Package;
use App\Test;
use App\Testrate;

use Auth;

class PackageController extends Controller
{
    
    public function packagelist(Request $request){

      if ($request->has('centerId')) {
        //$registrations = Registration:: where("patient_id", "=", $request->input('userId'))->first();
        $packagelist = package:: select('id','packages')->where([["center_id", "=", $request->input('centerId')], [ 'type', '=', '0' ] ])->orderBy('packages','ASC')->get();
        
    
        if ($packagelist) {
          
          $result = array();
          $result['packagelist'] = $packagelist;
          $result['success'] = 1;
          return response()->json($result);

        } else {
          
          $result['success'] = false;
          $result['massege'] = "Package Not Available!";

        }
      } else {
        return "Bad Request";
        $result['success'] = false;
        $result['massege'] = "Bad Request";
      }
    }


    
}