<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\User;
use App\Shcuser;
use App\Center;

use Auth;

class UserController extends Controller
{
    private $salt;
    public function __construct()
    {
        $this->salt="userloginregister";
    }
    

    public function register(Request $request){
      if ($request->has('username') && $request->has('password') && $request->has('mobile1')) {

        $shcuser = Shcuser::where("mobile1", "=", $request->input('mobile1'))->first();

         $result = array();
         

        //$user = new User;
        if($shcuser){

                    $Userexist = User::where("mobile1", "=", $request->input('mobile1'))->first();
                    if(!empty($Userexist->mobile1)){
                      $result['success'] = 0;
                      $result['message'] = "User already registered with this mobile number";
                      return response()->json($result);  
                    }

                    $user = new User;
                    $user->username = $request->input('mobile1');
                    $user->email = $request->input('email');
                    $user->name = $request->input('name');
                    $user->mobile1 = $request->input('mobile1');
                    $user->pat_id = $shcuser->id;
                    $user->password= app('hash')->make($request->input('password'));
                    if($user->save()){
                      $result['success'] = 1;
                      $result['message'] = "User registered successfully";
                      return response()->json($result);   
                    }
            } else {
                      $result['success'] = 0;
                      $result['message'] = "Mobile number OR dob does not match!";
                      return response()->json($result);   
                
            }
        } else {
                      $result['success'] = 0;
                      $result['message'] = "Enter all fields";
                      return response()->json($result);  
      }
    }

public function registerwithmobile(Request $request){
      if ($request->has('dob') && $request->has('password') && $request->has('mobile1')) {

        $shcuser = Shcuser::where("mobile1", "=", $request->input('mobile1'))->where("dob", "=", $request->input('dob'))->first();

         $result = array();
         

        //$user = new User;
        if($shcuser){

                    $Userexist = User::where("mobile1", "=", $request->input('mobile1'))->first();
                    if(!empty($Userexist->mobile1)){
                      $result['success'] = 0;
                      $result['message'] = "User already registered with this mobile number";
                      return response()->json($result);  
                    }

                    $user = new User;
                    $user->username = $request->input('mobile1');
                    $user->email = $shcuser->email;
                    $user->name = $shcuser->name;
                    $user->dob = $shcuser->dob;
                    $user->mobile1 = $request->input('mobile1');
                    $user->pat_id = $shcuser->id;
                    $user->password= app('hash')->make($request->input('password'));
                    if($user->save()){
                      $result['success'] = 1;
                      $result['message'] = "User registered successfully";
                      return response()->json($result);   
                    }
            } else {
                      $result['success'] = 0;
                      $result['message'] = "Mobile number OR dob does not match!";
                      return response()->json($result);   
                
            }
        } else {
                      $result['success'] = 0;
                      $result['message'] = "Enter all fields";
                      return response()->json($result);  
      }
    }


  
    public function info(){
      return Auth::user();
    }
}