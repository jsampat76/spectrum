<?php


namespace App;

use Illuminate\Database\Eloquent\Model;


class Testrate extends Model 
{

    protected $table = 'shc_pathtest_rates';
    
   
}