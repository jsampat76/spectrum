<?php

use Illuminate\Http\Request;
use Illuminate\Http\Response;



$app->get('/', function () use ($app) {
    return $app->version();
});



$app->post('user/registertest', 'UserController@registerTest');

$app->post('user/register', 'UserController@register');
$app->post('user/registerwithmobile', 'UserController@registerwithmobile');

//$app->post('user/login', 'UserController@login');
//$app->post('user/logintest', 'UserController@logintest');

$app->post('user/login', function(Request $request, Response $response) {
       $http = new GuzzleHttp\Client;

      $response = $http->post(env('API_URL', 'forge').'oauth/token', [
    'form_params' => [
        'grant_type' => 'password',
        'client_id' => 2,
        'client_secret' => 'lsErgn6G97uO18JDPNLx3oRqNzbHsi92CcdkkIxe',
        'username' => $request->input('username'),
        'password' => $request->input('password'),
        'scope' => '*',
      ],
      'http_errors' => false
    ]);        
         
         return $result = json_decode((string) $response->getBody(), true); 
          // return response()->json($response);  
});


  $app->group(['middleware' => 'auth:api', 'prefix' => 'user'], function () use ($app) {
  
      $app->get('info', 'UserController@info');

      //$app->get('getcenterlist/{departmentid}', 'CenterController@centerList');

      $app->get('getcenterlist', 'CenterController@centerList');

      $app->get('getappTests/{centerid}/{departmentid}', 'CenterController@appointmentTests');

      $app->post('getregistrationlist', 'RegistrationController@getregistrationlist');

      $app->get('alldepartments', 'DepartmentController@getalldepartments');

      $app->get('testlistforappointment', 'TestController@getTestlistforAppinment');

      //$app->post('gettestlist', 'TestController@gettestlist');
      $app->post('gettestlist', 'TestController@getTestswithdepartment');

      $app->post('getpackagelist', 'PackageController@packagelist');

      $app->post('testsearch', 'TestController@testsearch');

      $app->post('getreportresult', 'ReportController@getreportresult');

      $app->post('getreport', 'ReportController@getreport');

      $app->post('takeappointment', 'AppointmentController@registerAppointment');

    	$app->get('authenticated', function (Request $request) use ($app) {
            $result = array();
            $result['success'] = 1;
            $result['message'] = "User is athenticated";
            return response()->json($result);  
        });
      $app->post('sendCorpAppointment','EmailController@sendEmail');
      $app->post('sendTestsAppointment','EmailController@sendEmailTests');
});
